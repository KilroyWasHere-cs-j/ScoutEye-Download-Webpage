function redirectEmail(){
    window.location.href = "mailto:gabriel.tower@baxter-academy.org caleb.cole@baxter-academy.org?subject=&body=";
}

function redirectForm(){
    window.location.href = "https://docs.google.com/forms/d/e/1FAIpQLSeZrhP4T2JB0svs0TE-Po9x6Nf7HRRkRvxnSc7u2limTN8jWA/viewform?usp=sf_link";
}