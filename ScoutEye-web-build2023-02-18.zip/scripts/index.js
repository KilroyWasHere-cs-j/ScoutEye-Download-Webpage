function GitHubRedirect(){
    window.location.href = "https://github.com/frc5687/ScoutEye/releases";
}