# ScoutEye-Download-Webpage
A webpage to allow users to download the Desktop ScoutEye suite and the Android APK as well as host documentation for both.

- [X] Get webpage 
- [ ] Linlked button for installing Scouting app suite. Current installer link at this repo needs to find it's way into this web page: https://github.com/KilroyWasHere-cs-j/ScoutEyeInstallerLink
- [ ] APK installer link (APK needs to be done - Caleb that's a Gabe problem)
- [ ] Parallax for documentation (scrolling)
- [ ] Styling for web page


# Branching
Main is locked down so a pull request is needed to comit anything to main
Each change should get it's own issue and branch

### Branching naming schema

page/#(issue number)-(name of change)

*Example:*

Adds a install button the issue for this change is number 1

*page/#1-install_button*
