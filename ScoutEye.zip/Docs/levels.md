# ScoutEye makes use of a two-level system

The two levels are **Professional** and **Amateur**.


## Professional
This level is intended to be used to collect the most complete detailed data possible. This level is intended to be used by professional scouts or scouts who are very focused on collecting data. The goal of the professional level is to collect detailed data. 

## Amateur

This level is offered as an alternative to the professional level and is not recommended for serious scouts and/or teams that are extremely data-oriented.




It is unknown at this time whether the two-level system will see continued support into the future.