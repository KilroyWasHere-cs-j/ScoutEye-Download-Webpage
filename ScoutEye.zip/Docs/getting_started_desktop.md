# Getting started Desktop

This guide will give you all the tools needed to get started with ScoutEye for Windows

**Requirements**

These are the requirements that are needed to run ScoutEye on Windows

1. Windows 10+ 
2. Dot Net 4.8 or higher


## Download ScoutEye
This can be done by visiting our downloads page and downloading the Windows version.

Once the download has been completed the file can be extracted to any safe location. Open the file location and run ScoutEye.exe.
And that's it ScoutEye desktop is all set! It is wise to make a desktop [shortcut](https://support.microsoft.com/en-us/windows/pin-apps-and-folders-to-the-desktop-or-taskbar-f3c749fb-e298-4cf1-adda-7fd635df6bb0) for easy access or pin to the taskbar. 


